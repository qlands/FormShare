**Pattern**

Pattern is a web mining module for the Python programming language.

It has tools for data mining (Google, Twitter and Wikipedia API, a web crawler, a HTML DOM parser), natural language processing (part-of-speech taggers, n-gram search, sentiment analysis, WordNet), machine learning (vector space model, clustering, SVM), network analysis and <canvas> visualization

**This is minimal and modified version of Pattern to support pluralization in FormShare in Python 3. This would be removed in the future if Pattern is successfully ported to Python 3.**